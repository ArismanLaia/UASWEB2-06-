# UAS
Uas Pemrogramman Web 2

function input_relawan = untuk memasukan data relawan kedalam database.
function edit_relawan = untuk mengedit data relawan yang sudah ada di database.
function hapus = untuk menghapus data relawan yang ada didatabase.. 
function login_cek_nama = cek nama terdaftar belum. 
function cek_data = cek password Login.
function logout = user untuk keluar dari aplikasi.
