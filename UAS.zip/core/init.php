<?php

session_start();

require_once("model/db.php");
require_once("functions/controller_user.php");